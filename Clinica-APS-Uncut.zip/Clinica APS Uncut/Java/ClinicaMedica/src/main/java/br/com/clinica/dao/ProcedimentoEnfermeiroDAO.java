package br.com.clinica.dao;

import br.com.clinica.entity.ProcedimentoEnfermeiro;
import br.com.clinica.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProcedimentoEnfermeiroDAO implements GenericDAO<ProcedimentoEnfermeiro> {

    public int insert(ProcedimentoEnfermeiro procedimentoEnfermeiro) {

        int generatedKey = 0;

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "INSERT INTO procedimento_enfermeiro (ID_PROCEDIMENTO, ID_ENFERMEIRO) VALUES (?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setInt(1, procedimentoEnfermeiro.getProcedimento().getId());
            preparedStatement.setInt(2, procedimentoEnfermeiro.getEnfermeiro().getId());

            preparedStatement.execute();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {

                generatedKey = resultSet.getInt(1);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return generatedKey;
    }

    public void update(ProcedimentoEnfermeiro procedimentoEnfermeiro) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "UPDATE procedimento_enfermeiro SET ID_PROCEDIMENTO = ?, ID_ENFERMEIRO = ? " +
                    "WHERE ID_PROCEDIMENTO_ENFERMEIRO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, procedimentoEnfermeiro.getProcedimento().getId());
            preparedStatement.setInt(2, procedimentoEnfermeiro.getEnfermeiro().getId());
            preparedStatement.setInt(3, procedimentoEnfermeiro.getId());

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public ProcedimentoEnfermeiro find(Integer id) {

        ProcedimentoEnfermeiro procedimentoEnfermeiro = null;
        ProcedimentoDAO procedimentoDAO = new ProcedimentoDAO();
        EnfermeiroDAO enfermeiroDAO = new EnfermeiroDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimento_enfermeiro WHERE ID_PROCEDIMENTO_ENFERMEIRO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                procedimentoEnfermeiro = new ProcedimentoEnfermeiro();

                procedimentoEnfermeiro.setId(resultSet.getInt(1));
                procedimentoEnfermeiro.setProcedimento(procedimentoDAO.find(resultSet.getInt(2)));
                procedimentoEnfermeiro.setEnfermeiro(enfermeiroDAO.find(resultSet.getInt(3)));
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimentoEnfermeiro;
    }

    public List<ProcedimentoEnfermeiro> findAll() {

        List<ProcedimentoEnfermeiro> procedimentoEnfermeiros = new ArrayList<ProcedimentoEnfermeiro>();
        ProcedimentoDAO procedimentoDAO = new ProcedimentoDAO();
        EnfermeiroDAO enfermeiroDAO = new EnfermeiroDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimento_enfermeiro";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                ProcedimentoEnfermeiro procedimentoEnfermeiro = new ProcedimentoEnfermeiro();

                procedimentoEnfermeiro.setId(resultSet.getInt(1));
                procedimentoEnfermeiro.setProcedimento(procedimentoDAO.find(resultSet.getInt(2)));
                procedimentoEnfermeiro.setEnfermeiro(enfermeiroDAO.find(resultSet.getInt(3)));

                procedimentoEnfermeiros.add(procedimentoEnfermeiro);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimentoEnfermeiros;
    }

    public void delete(Integer id) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "DELETE FROM procedimento_enfermeiro WHERE ID_PROCEDIMENTO_ENFERMEIRO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
