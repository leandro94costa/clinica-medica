package br.com.clinica.cui;

import br.com.clinica.entity.Usuario;

public class EnfermeiroCUI {
    public void menu(Usuario usuario) {
    }
}
