package br.com.clinica.dao;

import br.com.clinica.entity.Procedimento;
import br.com.clinica.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProcedimentoDAO implements GenericDAO<Procedimento> {

    public int insert(Procedimento procedimento) {

        int generatedKey = 0;

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "INSERT INTO procedimentos (ID_PACIENTE, SALA, VALOR, TIPO, DESCRICAO) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setInt(1, procedimento.getPaciente().getId());
            preparedStatement.setString(2, procedimento.getSala());
            preparedStatement.setFloat(3, procedimento.getValor());
            preparedStatement.setString(4, procedimento.getTipo());
            preparedStatement.setString(5, procedimento.getDescricao());

            preparedStatement.execute();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {

                generatedKey = resultSet.getInt(1);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return generatedKey;
    }

    public void update(Procedimento procedimento) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "UPDATE procedimentos SET ID_PACIENTE = ?, SALA = ?, VALOR = ?, TIPO = ?, DESCRICAO = ? " +
                    "WHERE ID_PROCEDIMENTO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, procedimento.getPaciente().getId());
            preparedStatement.setString(2, procedimento.getSala());
            preparedStatement.setFloat(3, procedimento.getValor());
            preparedStatement.setString(4, procedimento.getTipo());
            preparedStatement.setString(5, procedimento.getDescricao());
            preparedStatement.setInt(6, procedimento.getId());

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public Procedimento find(Integer id) {

        Procedimento procedimento = null;
        PacienteDAO pacienteDAO = new PacienteDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimentos WHERE ID_PROCEDIMENTO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                procedimento = new Procedimento();

                procedimento.setId(resultSet.getInt(1));
                procedimento.setPaciente(pacienteDAO.find(resultSet.getInt(2)));
                procedimento.setSala(resultSet.getString(3));
                procedimento.setValor(resultSet.getFloat(4));
                procedimento.setTipo(resultSet.getString(5));
                procedimento.setDescricao(resultSet.getString(6));
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimento;
    }

    public List<Procedimento> findAll() {

        List<Procedimento> procedimentos = new ArrayList<Procedimento>();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimentos";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                Procedimento procedimento = new Procedimento();

                procedimento.setId(resultSet.getInt(1));
                procedimento.setDescricao(resultSet.getString(2));

                procedimentos.add(procedimento);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimentos;
    }

    public void delete(Integer id) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "DELETE FROM procedimentos WHERE ID_PROCEDIMENTO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
