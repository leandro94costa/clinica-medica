package br.com.clinica.entity;

public class Enfermeiro extends Funcionario {

    private Integer id;

    private String coren;

    private Funcionario funcionario;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCoren() {
        return coren;
    }

    public void setCoren(String coren) {

        if (coren.length() <= 20) {

            this.coren = coren;

        } else {

            return;
        }
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "Enfermeiro{" +
                "id=" + id +
                ", coren='" + coren + '\'' +
                ", funcionario=" + funcionario +
                '}';
    }
}
