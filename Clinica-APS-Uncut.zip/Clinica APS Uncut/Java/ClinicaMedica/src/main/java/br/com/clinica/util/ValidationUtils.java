package br.com.clinica.util;

public class ValidationUtils {

    public boolean checkIntegerLenght(Integer num, Integer limit) {

        if (String.valueOf(num).length() <= limit) {

            return true;

        } else {

            return false;
        }
    }

    public boolean checkLongLenght(Long num, Integer limit) {

        if (String.valueOf(num).length() <= limit) {

            return true;

        } else {

            return false;
        }
    }

    public boolean checkFloatLenght(Float num, Integer limit, Integer precision) {

        String decimal = String.valueOf(num % 1);
        String fraction = String.valueOf(num);

        fraction.substring(fraction.lastIndexOf(".") + 1);

        if (decimal.length() <= limit && fraction.length() == precision) {

            return true;

        } else {

            return false;
        }
    }
}
