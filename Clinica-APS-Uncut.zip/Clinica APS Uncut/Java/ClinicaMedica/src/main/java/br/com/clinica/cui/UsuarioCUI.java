package br.com.clinica.cui;

import br.com.clinica.entity.Medico;
import br.com.clinica.entity.Perfil;
import br.com.clinica.entity.Usuario;
import br.com.clinica.service.MedicoService;
import br.com.clinica.service.UsuarioService;

import java.util.Scanner;

public class UsuarioCUI extends GenericCUI {

    public void menu(Usuario usuario) {
    }

    public void perfil(Usuario usuario) {

        MenuCUI menuCUI = new MenuCUI();

        if (usuario.getPerfil().equals(Perfil.MEDICO)) {

            MedicoService medicoService = new MedicoService();

            Medico medico = medicoService.findMedicoByUsuario(usuario);

            System.out.println();
            System.out.println(usuario.getFuncionario().toString());
            System.out.println(medico.toString(""));
            System.out.println();

            menuCUI.menu(usuario);

        } else {

            System.out.println();
            System.out.println(usuario.getFuncionario().toString());
            System.out.println();

            menuCUI.menu(usuario);
        }
    }

    public Integer cadastrar(String metodo, Integer idFuncionario) {

        Scanner scanner = new Scanner(System.in);
        UsuarioService usuarioService = new UsuarioService();
        Integer perfil, idUsuario = null, result;
        String senha, confirmarSenha;

        System.out.println("\n" + "* Usuário do Sistema *" + "\n");

        System.out.println("E-mail (nome@email.com): ");
        String email = scanner.next();

        do {

            System.out.println("Senha: ");
            senha = scanner.next();

            System.out.println("Confirmar senha: ");
            confirmarSenha = scanner.next();

        } while (!senha.equals(confirmarSenha));

        do {

            System.out.println("Perfil (1 - ADMIN, 2 - MEDICO, 3 - USUARIO): ");
            perfil = scanner.nextInt();

        } while (perfil != 1 && perfil != 2 && perfil != 3);

		if (metodo.equals("alterar")) {
			
			idUsuario = usuarioService.findByFuncionario(idFuncionario);
		}

        result = usuarioService.save(idUsuario, email, senha, perfil, idFuncionario);

        return result;
    }
}
