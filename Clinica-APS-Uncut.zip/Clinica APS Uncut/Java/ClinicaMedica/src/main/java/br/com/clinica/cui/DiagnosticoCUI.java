package br.com.clinica.cui;

import java.util.Optional;

public class DiagnosticoCUI {

    public void menu(Object... objects) {
    }
}
