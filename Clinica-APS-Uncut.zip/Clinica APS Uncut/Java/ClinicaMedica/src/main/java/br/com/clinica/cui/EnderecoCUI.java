package br.com.clinica.cui;

public class EnderecoCUI {

    public void menu() {
    }
}
