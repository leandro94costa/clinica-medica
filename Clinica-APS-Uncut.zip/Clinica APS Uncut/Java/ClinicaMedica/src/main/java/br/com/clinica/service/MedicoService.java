package br.com.clinica.service;

import br.com.clinica.dao.MedicoDAO;
import br.com.clinica.entity.Medico;
import br.com.clinica.entity.Usuario;

import java.util.List;

public class MedicoService {

    public List<Medico> findByNome(String nome) {

        MedicoDAO medicoDAO = new MedicoDAO();

        List<Medico> medicos = medicoDAO.findMedicosByNome(nome);

        return medicos;
    }

    public Medico findById(Integer id) {

        MedicoDAO medicoDAO = new MedicoDAO();

        Medico medico = medicoDAO.find(id);

        return medico;
    }

    public Medico findMedicoByUsuario(Usuario usuario) {

        MedicoDAO medicoDAO = new MedicoDAO();

        Medico medico = medicoDAO.findMedicoByFuncionario(usuario.getFuncionario().getId());

        return medico;
    }

    public Medico save(Medico medico) {

        MedicoDAO medicoDAO = new MedicoDAO();

        if (medico.getId() == null) {

            medico = medicoDAO.find(medicoDAO.insert(medico));

        } else {

            medicoDAO.update(medico);

            if (isPersisted(medico)) {

                return medico;
            }
        }

        return medico;
    }

    private boolean isPersisted(Medico medico) {

        MedicoDAO medicoDAO = new MedicoDAO();

        Medico medicoPersisted = medicoDAO.find(medico.getId());

        if (medico.equals(medicoPersisted)) {

            return true;

        } else {

            return false;
        }
    }
}
