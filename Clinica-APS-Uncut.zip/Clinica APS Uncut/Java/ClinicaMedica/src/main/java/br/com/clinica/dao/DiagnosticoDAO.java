package br.com.clinica.dao;

import br.com.clinica.entity.Diagnostico;
import br.com.clinica.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DiagnosticoDAO implements GenericDAO<Diagnostico> {

    public int insert(Diagnostico diagnostico) {

        int generatedKey = 0;

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "INSERT INTO diagnosticos (CID, PRESCRICAO, ID_CONSULTA) VALUES (?, ?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setString(1, diagnostico.getCid());
            preparedStatement.setString(2, diagnostico.getPrescricao());
            preparedStatement.setInt(3, diagnostico.getConsulta().getId());

            preparedStatement.execute();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {

                generatedKey = resultSet.getInt(1);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return generatedKey;
    }

    public void update(Diagnostico diagnostico) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "UPDATE diagnosticos SET CID = ?, PRESCRICAO = ?, ID_CONSULTA = ? WHERE ID_DIAGNOSTICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, diagnostico.getCid());
            preparedStatement.setString(2, diagnostico.getPrescricao());
            preparedStatement.setInt(3, diagnostico.getConsulta().getId());
            preparedStatement.setInt(4, diagnostico.getId());

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public Diagnostico find(Integer id) {

        Diagnostico diagnostico = null;
        ConsultaDAO consultaDAO = new ConsultaDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM diagnosticos WHERE ID_DIAGNOSTICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                diagnostico = new Diagnostico();

                diagnostico.setId(resultSet.getInt(1));
                diagnostico.setCid(resultSet.getString(2));
                diagnostico.setPrescricao(resultSet.getString(3));
                diagnostico.setConsulta(consultaDAO.find(resultSet.getInt(4)));
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return diagnostico;
    }

    public List<Diagnostico> findAll() {

        List<Diagnostico> diagnosticos = new ArrayList<Diagnostico>();
        ConsultaDAO consultaDAO = new ConsultaDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM diagnosticos";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                Diagnostico diagnostico = new Diagnostico();

                diagnostico.setId(resultSet.getInt(1));
                diagnostico.setCid(resultSet.getString(2));
                diagnostico.setPrescricao(resultSet.getString(3));
                diagnostico.setConsulta(consultaDAO.find(resultSet.getInt(4)));

                diagnosticos.add(diagnostico);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return diagnosticos;
    }

    public void delete(Integer id) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "DELETE FROM diagnosticos WHERE ID_DIAGNOSTICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
