package br.com.clinica.cui;

import br.com.clinica.entity.Usuario;

public abstract class GenericCUI {

    public abstract void menu(Usuario usuario);
}
