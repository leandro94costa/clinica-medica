package br.com.clinica.dao;

import br.com.clinica.entity.Enfermeiro;
import br.com.clinica.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EnfermeiroDAO implements GenericDAO<Enfermeiro> {

    public int insert(Enfermeiro enfermeiro) {

        int generatedKey = 0;

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "INSERT INTO enfermeiros (COREN, ID_FUNCIONARIO) VALUES (?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setString(1, enfermeiro.getCoren());
            preparedStatement.setInt(2, enfermeiro.getFuncionario().getId());

            preparedStatement.execute();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {

                generatedKey = resultSet.getInt(1);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return generatedKey;
    }

    public void update(Enfermeiro enfermeiro) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "UPDATE enfermeiros SET COREN = ?, ID_FUNCIONARIO = ? WHERE ID_ENFERMEIRO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, enfermeiro.getCoren());
            preparedStatement.setInt(2, enfermeiro.getFuncionario().getId());
            preparedStatement.setInt(3, enfermeiro.getId());

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public Enfermeiro find(Integer id) {

        Enfermeiro enfermeiro = null;
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM enfermeiros WHERE ID_ENFERMEIROS = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                enfermeiro = new Enfermeiro();

                enfermeiro.setId(resultSet.getInt(1));
                enfermeiro.setCoren(resultSet.getString(2));
                enfermeiro.setFuncionario(funcionarioDAO.find(resultSet.getInt(3)));
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return enfermeiro;
    }

    public List<Enfermeiro> findAll() {

        List<Enfermeiro> enfermeiros = new ArrayList<Enfermeiro>();
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM enfermeiros";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                Enfermeiro enfermeiro = new Enfermeiro();

                enfermeiro.setId(resultSet.getInt(1));
                enfermeiro.setCoren(resultSet.getString(2));
                enfermeiro.setFuncionario(funcionarioDAO.find(resultSet.getInt(3)));

                enfermeiros.add(enfermeiro);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return enfermeiros;
    }

    public void delete(Integer id) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "DELETE FROM enfermeiros WHERE ID_ENFERMEIRO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
