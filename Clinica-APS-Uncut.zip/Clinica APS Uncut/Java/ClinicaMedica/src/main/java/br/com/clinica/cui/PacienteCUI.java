package br.com.clinica.cui;

import br.com.clinica.entity.Endereco;
import br.com.clinica.entity.Paciente;
import br.com.clinica.entity.Usuario;
import br.com.clinica.service.EnderecoService;
import br.com.clinica.service.PacienteService;

import java.util.List;
import java.util.Scanner;

public class PacienteCUI extends GenericCUI {

    @Override
    public void menu(Usuario usuario) {

        Scanner scanner = new Scanner(System.in);
        Integer opcao = -1;

        System.out.println("--------------------------------------------------------------");
        System.out.println("** Pacientes **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        do {

            System.out.println(" 1 - Cadastrar");
            System.out.println();
            System.out.println(" 2 - Alterar");
            System.out.println();
            System.out.println(" 0 - Voltar");
            System.out.println();

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    cadastrarOuAlterar(usuario, "cadastrar");
                    break;

                case 2:
                    cadastrarOuAlterar(usuario, "alterar");
                    break;

                case 0:
                    MenuCUI menuCUI = new MenuCUI();
                    menuCUI.menu(usuario);
                    break;

                default:
                    System.err.println("Opção inválida, tente novamente");
                    break;
            }

        } while (opcao < 0 || opcao > 2);

        menu(usuario);
    }

    private void cadastrarOuAlterar(Usuario usuario, String metodo) {

        Scanner scanner = new Scanner(System.in);
        Paciente paciente = new Paciente();
        EnderecoService enderecoService = new EnderecoService();
        PacienteService pacienteService = new PacienteService();
        Integer resultado;

        String titulo = metodo.substring(1);

        System.out.println("--------------------------------------------------------------");
        System.out.println("** A" + titulo + " Paciente **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        if (metodo.equals("alterar")) {

            paciente = buscarPaciente();

            System.out.println("\n" + "Novas informações" + "\n");
        }

        do {

            System.out.println("Nome Completo: ");
            String nome = scanner.next();

            System.out.println("CPF (somente números): ");
            Long cpf = scanner.nextLong();

            System.out.println("Data Nascimento (01/01/1999): ");
            String dataNascimento = scanner.next();

            System.out.println("\n" + "* Endereço *" + "\n");

            System.out.println("Logradouro (Rua Um): ");
            String logradouro = scanner.next();

            System.out.println("Número (100):");
            Integer numero = scanner.nextInt();

            System.out.println("Bairro: ");
            String bairro = scanner.next();

            System.out.println("Complemento (ou 0 para pular): ");
            String complemento = scanner.next();

            System.out.println("Cidade: ");
            String cidade = scanner.next();

            System.out.println("Estado (São Paulo): ");
            String estado = scanner.next();

            System.out.println("Cep (12345678) (ou 0 para pular): ");
            Integer cep = scanner.nextInt();

            Integer idEndereco = paciente.getEndereco().getId() != null ? paciente.getEndereco().getId() : null;

            Endereco endereco = enderecoService.save(idEndereco, logradouro, numero, bairro, complemento, cidade, estado, cep);

            Integer idPaciente = paciente.getId() != null ? paciente.getId() : null;

            resultado = pacienteService.save(idPaciente, nome, cpf, dataNascimento, endereco);

            if (resultado == 0) {

                System.err.println("Erro ao " + metodo + " paciente");
                System.out.println("Digite:" + "\n" + "0 - Tentar novamente"  + "\n" + "1 - Voltar");
                resultado = scanner.nextInt();

            } else {

                metodo = metodo.equals("cadastrar") ? "cadastrado" : "alterado";

                System.out.println();
                System.out.println("Paciente " + metodo + " com sucesso");
                System.out.println();
            }

        } while (resultado == 0);

        menu(usuario);
    }

    public Paciente buscarPaciente() {

        Scanner scanner = new Scanner(System.in);
        PacienteService pacienteService = new PacienteService();
        Integer idPaciente = 0;

        do {

            System.out.println("Digite o nome do paciente para buscar: ");
            String nomePaciente = scanner.next();

            List<Paciente> pacientes = pacienteService.findByNome(nomePaciente);

            if (pacientes.isEmpty()) {

                System.err.println("\n" + "Paciente não encontrado" + "\n");

            } else {

                System.out.println();
                pacientes.forEach(System.out::println);
                System.out.println();

                System.out.println("Digite o ID do paciente ou 0 para buscar novamente");
                idPaciente = scanner.nextInt();
            }

        } while (idPaciente == 0);

        Paciente paciente = pacienteService.findById(idPaciente);

        return paciente;
    }
}
