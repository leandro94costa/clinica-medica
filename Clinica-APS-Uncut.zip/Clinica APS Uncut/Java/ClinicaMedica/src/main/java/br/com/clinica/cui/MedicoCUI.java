package br.com.clinica.cui;

import br.com.clinica.entity.*;
import br.com.clinica.service.MedicoEspecialidadeService;
import br.com.clinica.service.MedicoService;

import java.util.List;
import java.util.Scanner;

public class MedicoCUI extends GenericCUI {

    public void menu(Usuario usuario) {

        Scanner scanner = new Scanner(System.in);
        Integer opcao = -1;

        System.out.println("--------------------------------------------------------------");
        System.out.println("** Médicos **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        do {

            System.out.println(" 1 - Cadastrar");
            System.out.println();
            System.out.println(" 2 - Alterar");
            System.out.println();
            System.out.println(" 0 - Voltar");
            System.out.println();

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    cadastrarOuAlterar(usuario, "cadastrar");
                    break;

                case 2:
                    cadastrarOuAlterar(usuario, "alterar");
                    break;

                case 0:
                    MenuCUI menuCUI = new MenuCUI();
                    menuCUI.menu(usuario);
                    break;

                default:
                    System.err.println("Opção inválida, tente novamente");
                    break;
            }

        } while (opcao < 0 && opcao > 2);
    }

    private void cadastrarOuAlterar(Usuario usuario, String metodo) {

        Scanner scanner = new Scanner(System.in);
        Medico medico = null;
        MedicoService medicoService = new MedicoService();
        FuncionarioCUI funcionarioCUI = new FuncionarioCUI();
        EspecialidadeCUI especialidadeCUI = new EspecialidadeCUI();
        MedicoEspecialidadeService medicoEspecialidadeService = new MedicoEspecialidadeService();
        Integer resultado = 0;

        String titulo = metodo.substring(1);

        System.out.println("--------------------------------------------------------------");
        System.out.println("** A" + titulo + " Médico **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        if (metodo.equals("alterar")) {

            medico = buscarMedico();

            System.out.println("\n" + "Novas informações" + "\n");
        }

        do {

            System.out.println("CRM (CRM/SP 12345): ");
            String crm = scanner.next();

            Funcionario funcionario = funcionarioCUI.buscarFuncionario();

            medico.setCrm(crm);
            medico.setFuncionario(funcionario);

            medico = medicoService.save(medico);

            List<Especialidade> especialidades = especialidadeCUI.cadastrarEspecialidadesMedico(medico.getId());

            for (Especialidade especialidade : especialidades) {

                resultado += medicoEspecialidadeService.add(especialidade, medico);
            }

            if (especialidades.size() == resultado) {

                metodo = metodo.equals("cadastrar") ? "cadastrado" : "alterado";

                System.out.println();
                System.out.println("Funcionário " + metodo + " com sucesso");
                System.out.println();

            } else {

                System.err.println("Erro ao " + metodo + " médico");
                System.out.println("Digite:" + "\n" + "0 - Tentar novamente"  + "\n" + "1 - Voltar");
                resultado = scanner.nextInt();
            }

        } while (resultado == 0);

        menu(usuario);
    }

    public Medico buscarMedico() {

        Scanner scanner = new Scanner(System.in);
        MedicoService medicoService = new MedicoService();
        Integer idMedico = 0;

        do {

            System.out.println("Digite o nome do medico para buscar: ");
            String nomeMedico = scanner.next();

            List<Medico> medicos = medicoService.findByNome(nomeMedico);

            if (medicos.isEmpty()) {

                System.out.println("\n" + "Medico não encontrado" + "\n");

            } else {

                System.out.println();
                medicos.forEach(System.out::println);
                System.out.println();

                System.out.println("Digite o ID do médico ou 0 para buscar novamente");
                idMedico = scanner.nextInt();
            }

        } while (idMedico == 0);

        Medico medico = medicoService.findById(idMedico);

        return medico;
    }
}
