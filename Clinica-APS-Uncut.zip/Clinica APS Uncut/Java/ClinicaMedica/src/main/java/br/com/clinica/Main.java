package br.com.clinica;

import br.com.clinica.cui.LoginCUI;

public class Main {

    public static void main(String[] args) {

        LoginCUI loginCUI = new LoginCUI();

        loginCUI.LogIn();
    }
}
