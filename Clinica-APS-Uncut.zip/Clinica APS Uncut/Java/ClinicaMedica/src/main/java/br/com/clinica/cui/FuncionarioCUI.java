package br.com.clinica.cui;

import br.com.clinica.entity.Endereco;
import br.com.clinica.entity.Funcionario;
import br.com.clinica.entity.Usuario;
import br.com.clinica.service.EnderecoService;
import br.com.clinica.service.FuncionarioService;

import java.util.List;
import java.util.Scanner;

public class FuncionarioCUI extends GenericCUI {
    
    public void menu(Usuario usuario) {

        Scanner scanner = new Scanner(System.in);
        Integer opcao = -1;

        System.out.println("--------------------------------------------------------------");
        System.out.println("** Funcionários **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        do {

            System.out.println(" 1 - Cadastrar");
            System.out.println();
            System.out.println(" 2 - Alterar");
            System.out.println();
            System.out.println(" 3 - Demitir");
            System.out.println();
            System.out.println(" 0 - Voltar");
            System.out.println();

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    cadastrarOuAlterar(usuario, "cadastrar");
                    break;

                case 2:
                    cadastrarOuAlterar(usuario, "alterar");
                    break;

                case 3:
                    demitir(usuario);
                    break;

                case 0:
                    MenuCUI menuCUI = new MenuCUI();
                    menuCUI.menu(usuario);
                    break;

                default:
                    System.err.println("Opção inválida, tente novamente");
                    break;
            }

        } while (opcao < 0 || opcao > 3);
    }

    private void cadastrarOuAlterar(Usuario usuario, String metodo) {

        Scanner scanner = new Scanner(System.in);
        Funcionario funcionario = null;
        EnderecoService enderecoService = new EnderecoService();
        FuncionarioService funcionarioService = new FuncionarioService();
        UsuarioCUI usuarioCUI = new UsuarioCUI();

        Integer resultado;

        String titulo = metodo.substring(1);

        System.out.println("--------------------------------------------------------------");
        System.out.println("** A" + titulo + " Funcionário **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        if (metodo.equals("alterar")) {

            funcionario = buscarFuncionario();

            System.out.println("\n" + "Novas informações" + "\n");
        }

        do {

            System.out.println("Nome Completo: ");
            String nome = scanner.next();

            System.out.println("CPF (somente números): ");
            Long cpf = scanner.nextLong();

            System.out.println("Data Nascimento (01/01/1999): ");
            String dataNascimento = scanner.next();

            System.out.println("Data Admissão (01/01/1999): ");
            String dataAdmissao = scanner.next();

            System.out.println("Salário (9999.99): ");
            Float salario = scanner.nextFloat();

            System.out.println("Função: ");
            String funcao = scanner.next();

            System.out.println("\n" + "* Endereço *" + "\n");

            System.out.println("Logradouro (Rua Um): ");
            String logradouro = scanner.next();

            System.out.println("Número (100):");
            Integer numero = scanner.nextInt();

            System.out.println("Bairro: ");
            String bairro = scanner.next();

            System.out.println("Complemento (ou 0 para pular): ");
            String complemento = scanner.next();

            System.out.println("Cidade: ");
            String cidade = scanner.next();

            System.out.println("Estado (São Paulo): ");
            String estado = scanner.next();

            System.out.println("Cep (12345678) (ou 0 para pular): ");
            Integer cep = scanner.nextInt();

            Integer idEndereco = funcionario.getEndereco().getId() != null ? funcionario.getEndereco().getId() : null;

            Endereco endereco = enderecoService.save(idEndereco, logradouro, numero, bairro, complemento, cidade, estado, cep);

            Integer idFuncionario = funcionario.getId() != null ? funcionario.getId() : null;

            funcionario = funcionarioService.save(idFuncionario, nome, cpf, dataNascimento, dataAdmissao, null,
                    salario, funcao, endereco);

            resultado = usuarioCUI.cadastrar(metodo, funcionario.getId());

            if (resultado == 0) {

                System.err.println("Erro ao " + metodo + " funcionário");
                System.out.println("Digite:" + "\n" + "0 - Tentar novamente"  + "\n" + "1 - Voltar");
                resultado = scanner.nextInt();

            } else {

                metodo = metodo.equals("cadastrar") ? "cadastrado" : "alterado";

                System.out.println();
                System.out.println("Funcionário " + metodo + " com sucesso");
                System.out.println();
            }

        } while (resultado == 0);

        menu(usuario);
    }

    private void demitir(Usuario usuario) {

        Scanner scanner = new Scanner(System.in);
        FuncionarioService funcionarioService = new FuncionarioService();
        Integer resposta;

        do {

            Funcionario funcionario = buscarFuncionario();

            System.out.println("Data de demissão (01/01/1999):");
            String dataDemissao = scanner.next();

            System.out.println("Confirmar a demissão do funcionário(a) " + funcionario.getNome() + " ?" + "\n" +
                    "1 - Sim" + "\n" + "2 - Não");
            resposta = scanner.nextInt();

            if (resposta == 1) {

                if (funcionarioService.demitir(funcionario.getId(), dataDemissao)) {

                    System.out.println("\n" + "Funcionário demitido com sucesso" + "\n");

                } else {

                    System.err.println("\n" + "Erro ao demitir funcionário" + "\n");

                    System.out.println("Buscar novamente?" + "\n" + "0 - Sim" + "\n" + "1 - Não");
                    resposta = scanner.nextInt();
                }

            } else {

                System.out.println("Buscar novamente?" + "\n" + "0 - Sim" + "\n" + "1 - Não");
                resposta = scanner.nextInt();
            }

        } while (resposta == 0);

        menu(usuario);
    }

    public Funcionario buscarFuncionario() {

        Scanner scanner = new Scanner(System.in);
        FuncionarioService funcionarioService = new FuncionarioService();
        Integer idFuncionario = 0;

        do {

            System.out.println("Digite o nome do funcionário para buscar: ");
            String nomeFuncionario = scanner.next();

            List<Funcionario> funcionarios = funcionarioService.findByNome(nomeFuncionario);

            if (funcionarios.isEmpty()) {

                System.err.println("\n" + "Funcionário não encontrado" + "\n");

            } else {

                System.out.println();
                funcionarios.forEach(System.out::println);
                System.out.println();

                System.out.println("Digite o ID do funcionário ou 0 para buscar novamente");
                idFuncionario = scanner.nextInt();
            }

        } while (idFuncionario == 0);

        Funcionario funcionario = funcionarioService.findById(idFuncionario);

        return funcionario;
    }
}
