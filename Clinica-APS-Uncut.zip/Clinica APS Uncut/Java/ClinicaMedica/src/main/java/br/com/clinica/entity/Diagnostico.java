package br.com.clinica.entity;

public class Diagnostico {

    private Integer id;

    private String cid;

    private String prescricao;

    private Consulta consulta;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {

        if (cid.length() <= 3){

            this.cid = cid;

        } else {

            return;
        }
    }

    public String getPrescricao() {
        return prescricao;
    }

    public void setPrescricao(String prescricao) {

        if (prescricao.length() <= 65535) {

            this.prescricao = prescricao;

        } else {

            return;
        }
    }

    public Consulta getConsulta() {
        return consulta;
    }

    public void setConsulta(Consulta consulta) {
        this.consulta = consulta;
    }

    @Override
    public String toString() {
        return "Diagnostico{" +
                "id=" + id +
                ", cid='" + cid + '\'' +
                ", prescricao='" + prescricao + '\'' +
                ", consulta=" + consulta +
                '}';
    }
}
