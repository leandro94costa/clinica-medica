package br.com.clinica.entity;

public class Usuario {

    private Integer id;

    private String email;

    private String senha;

    private Perfil perfil;

    private Funcionario funcionario;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {

        if (email.length() <= 45) {

            this.email = email;

        } else {

            return;
        }
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {

        if (senha.length() <= 45) {

            this.senha = senha;

        } else {

            return;
        }
    }

    public Perfil getPerfil() {
        return perfil;
    }

    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", senha='" + senha + '\'' +
                ", perfil=" + perfil +
                ", funcionario=" + funcionario +
                '}';
    }
}
