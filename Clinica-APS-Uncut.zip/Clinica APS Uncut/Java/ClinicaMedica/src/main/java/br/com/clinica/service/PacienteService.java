package br.com.clinica.service;

import br.com.clinica.dao.PacienteDAO;
import br.com.clinica.entity.Endereco;
import br.com.clinica.entity.Paciente;
import br.com.clinica.util.FormatterUtil;

import java.util.List;

public class PacienteService {

    public List<Paciente> findByNome(String nome) {

        PacienteDAO pacienteDAO = new PacienteDAO();

        List<Paciente> pacientes = pacienteDAO.findPacientesByNome(nome);

        return pacientes;
    }

    public Paciente findById(Integer id) {

        PacienteDAO pacienteDAO = new PacienteDAO();

        Paciente paciente = pacienteDAO.find(id);

        return paciente;
    }

    public Integer save(Integer id, String nome, Long cpf, String dataNascimento, Endereco endereco) {

        Paciente paciente = create(id, nome, cpf, dataNascimento, endereco);

        PacienteDAO pacienteDAO = new PacienteDAO();
        Integer result = 0;

        if (paciente.getId() == null) {

            result = pacienteDAO.insert(paciente);

        } else {

            pacienteDAO.update(paciente);

            if (isPersisted(paciente)) {

                result = 1;
            }
        }

        return result;
    }

    private boolean isPersisted(Paciente paciente) {

        PacienteDAO pacienteDAO = new PacienteDAO();

        Paciente pacientePersisted = pacienteDAO.find(paciente.getId());

        if (paciente.equals(pacientePersisted)) {

            return true;

        } else {

            return false;
        }
    }

    private Paciente create(Integer id, String nome, Long cpf, String dataNascimento, Endereco endereco) {

        FormatterUtil formatterUtil = new FormatterUtil();
        Paciente paciente = null;

        if (id != null) {

            paciente.setId(id);
        }

        paciente.setNome(nome);
        paciente.setCpf(cpf);
        paciente.setDataNascimento(formatterUtil.formatDate(dataNascimento));
        paciente.setEndereco(endereco);

        return paciente;
    }
}
