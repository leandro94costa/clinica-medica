package br.com.clinica.service;

import br.com.clinica.dao.FuncionarioDAO;
import br.com.clinica.dao.UsuarioDAO;
import br.com.clinica.entity.Perfil;
import br.com.clinica.entity.Usuario;

public class UsuarioService {

    public Perfil findPerfil(String perfil) {

        if (perfil.equals(Perfil.ADMIN.toString())) {

            return Perfil.ADMIN;

        } else if (perfil.equals(Perfil.MEDICO.toString())) {

            return Perfil.MEDICO;

        } if (perfil.equals(Perfil.ENFERMEIRO.toString())) {

            return Perfil.ENFERMEIRO;

        } else {

            return Perfil.USUARIO;
        }
    }

    public Integer save(Integer idUsuario, String email, String senha, Integer perfil, Integer idFuncionario) {

        UsuarioDAO usuarioDAO = new UsuarioDAO();
        Integer result = 0;

        Usuario usuario = create(idUsuario, email, senha, perfil, idFuncionario);

        if (usuario.getId() != null) {

            result = usuarioDAO.insert(usuario);

        } else {

            usuarioDAO.update(usuario);

            if (!isPersisted(usuario)) {

                result = 1;
            }
        }

        return result;
    }

    private boolean isPersisted(Usuario usuario) {

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        Usuario usuarioPersisted = usuarioDAO.find(usuario.getId());

        if (usuario.equals(usuarioPersisted)) {

            return true;

        } else {

            return false;
        }
    }

    private Usuario create(Integer idUsuario, String email, String senha, Integer perfil, Integer idFuncionario) {

        Usuario usuario = new Usuario();
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
		
		if (idUsuario > 0) {
			
			usuario.setId(idUsuario);
		}

        usuario.setEmail(email);
        usuario.setSenha(senha);
        usuario.setFuncionario(funcionarioDAO.find(idFuncionario));

        if (perfil == 1) {

            usuario.setPerfil(findPerfil("ADMIN"));

        } if (perfil == 2) {

            usuario.setPerfil(findPerfil("MEDICO"));

        } else {

            usuario.setPerfil(findPerfil("USUARIO"));
        }

        return usuario;
    }

    public Integer findByFuncionario(Integer idFuncionario) {

        UsuarioDAO usuarioDAO = new UsuarioDAO();

        return usuarioDAO.findUsuarioByFuncionario(idFuncionario);
    }
}
