package br.com.clinica.dao;

import br.com.clinica.entity.ProcedimentoMedico;
import br.com.clinica.util.ConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProcedimentoMedicoDAO implements GenericDAO<ProcedimentoMedico> {

    public int insert(ProcedimentoMedico procedimentoMedico) {

        int generatedKey = 0;

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "INSERT INTO procedimento_medico (ID_PROCEDIMENTO, ID_MEDICO) VALUES (?, ?)";

            PreparedStatement preparedStatement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            preparedStatement.setInt(1, procedimentoMedico.getProcedimento().getId());
            preparedStatement.setInt(2, procedimentoMedico.getMedico().getId());

            preparedStatement.execute();

            ResultSet resultSet = preparedStatement.getGeneratedKeys();

            if (resultSet.next()) {

                generatedKey = resultSet.getInt(1);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return generatedKey;
    }

    public void update(ProcedimentoMedico procedimentoMedico) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "UPDATE procedimento_medico SET ID_PROCEDIMENTO = ?, ID_MEDICO = ? " +
                    "WHERE ID_PROCEDIMENTO_MEDICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, procedimentoMedico.getProcedimento().getId());
            preparedStatement.setInt(2, procedimentoMedico.getMedico().getId());
            preparedStatement.setInt(3, procedimentoMedico.getId());

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public ProcedimentoMedico find(Integer id) {

        ProcedimentoMedico procedimentoMedico = null;
        ProcedimentoDAO procedimentoDAO = new ProcedimentoDAO();
        MedicoDAO medicoDAO = new MedicoDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimento_medico WHERE ID_PROCEDIMENTO_MEDICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {

                procedimentoMedico = new ProcedimentoMedico();

                procedimentoMedico.setId(resultSet.getInt(1));
                procedimentoMedico.setProcedimento(procedimentoDAO.find(resultSet.getInt(2)));
                procedimentoMedico.setMedico(medicoDAO.find(resultSet.getInt(3)));
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimentoMedico;
    }

    public List<ProcedimentoMedico> findAll() {

        List<ProcedimentoMedico> procedimentoMedicos = new ArrayList<ProcedimentoMedico>();
        ProcedimentoDAO procedimentoDAO = new ProcedimentoDAO();
        MedicoDAO medicoDAO = new MedicoDAO();

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "SELECT * FROM procedimento_medico";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                ProcedimentoMedico procedimentoMedico = new ProcedimentoMedico();

                procedimentoMedico.setId(resultSet.getInt(1));
                procedimentoMedico.setProcedimento(procedimentoDAO.find(resultSet.getInt(2)));
                procedimentoMedico.setMedico(medicoDAO.find(resultSet.getInt(3)));

                procedimentoMedicos.add(procedimentoMedico);
            }

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }

        return procedimentoMedicos;
    }

    public void delete(Integer id) {

        try {

            Connection connection = ConnectionUtil.getInstance().getConnection();

            String sql = "DELETE FROM procedimento_medico WHERE ID_PROCEDIMENTO_MEDICO = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setInt(1, id);

            preparedStatement.execute();

            connection.close();

        } catch (Exception e) {

            e.printStackTrace();
        }
    }
}
