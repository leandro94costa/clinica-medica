package br.com.clinica.service;

import br.com.clinica.dao.FuncionarioDAO;
import br.com.clinica.entity.Endereco;
import br.com.clinica.entity.Funcionario;
import br.com.clinica.util.FormatterUtil;

import java.util.List;

public class FuncionarioService {

    public List<Funcionario> findByNome(String nomeFuncionario) {

        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        List<Funcionario> funcionarios = funcionarioDAO.findFuncionariosByNome(nomeFuncionario);

        return funcionarios;
    }

    public Funcionario findById(Integer idFuncionario) {

        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        return funcionarioDAO.find(idFuncionario);
    }

    public Boolean demitir(Integer id, String dataDemissao) {

        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        funcionarioDAO.demitir(id, dataDemissao);

        Boolean result = false;

        if (isDismissed(id)) {

            result = true;
        }

        return result;
    }

    public boolean isDismissed(Integer id) {

        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        Boolean dismissed = false;

        Funcionario funcionario = funcionarioDAO.find(id);

        if (funcionario.getDataDemissao() != null) {

            dismissed = true;
        }

        return dismissed;
    }

    public Funcionario save(Integer idFuncionario, String nome, Long cpf, String dataNascimento, String dataAdmissao,
                        String dataDemissao, Float salario, String funcao, Endereco endereco) {

        Integer result = 0;
        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        Funcionario funcionario = create(idFuncionario, nome, cpf, dataNascimento, dataAdmissao, dataDemissao, salario,
                funcao, endereco);

        if (funcionario.getId() == null) {

            funcionario = funcionarioDAO.find(funcionarioDAO.insert(funcionario));

        } else {

            funcionarioDAO.update(funcionario);

            if (isPersisted(funcionario)) {

                funcionario = funcionarioDAO.find(funcionario.getId());
            }
        }

        return funcionario;
    }

    private boolean isPersisted(Funcionario funcionario) {

        FuncionarioDAO funcionarioDAO = new FuncionarioDAO();

        Funcionario funcionarioPersisted = funcionarioDAO.find(funcionario.getId());

        if (funcionario.equals(funcionarioPersisted)) {

            return true;

        } else {

            return false;
        }
    }

    private Funcionario create(Integer id, String nome, Long cpf, String dataNascimento, String dataAdmissao,
                              String dataDemissao, Float salario, String funcao, Endereco endereco) {

        FormatterUtil formatterUtil = new FormatterUtil();
        Funcionario funcionario = new Funcionario();

        if (id != null) {

            funcionario.setId(id);
        }

        if (dataDemissao != null) {

            funcionario.setDataDemissao(formatterUtil.formatDate(dataDemissao));
        }

        funcionario.setNome(nome);
        funcionario.setCpf(cpf);
        funcionario.setDataNascimento(formatterUtil.formatDate(dataNascimento));
        funcionario.setDataAdmissao(formatterUtil.formatDate(dataAdmissao));
        funcionario.setSalario(salario);
        funcionario.setFuncao(funcao);
        funcionario.setEndereco(endereco);

        return funcionario;
    }
}
