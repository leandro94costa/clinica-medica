package br.com.clinica.cui;

import br.com.clinica.entity.Usuario;

public class ProcedimentoCUI {
    public void menu(Usuario usuario) {
    }
}
