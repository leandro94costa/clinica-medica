package br.com.clinica.entity;

public enum Perfil {

    ADMIN, MEDICO, ENFERMEIRO, USUARIO;
}
