package br.com.clinica.entity;

import br.com.clinica.util.ValidationUtils;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class Procedimento {

    private Integer id;

    private Paciente paciente;

    private String sala;

    private Float valor;

    private String tipo;

    private LocalDate data;

    private LocalTime horario;

    private String descricao;

    private List<Medico> medicos;

    private List<Enfermeiro> enfermeiros;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public String getSala() {
        return sala;
    }

    public void setSala(String sala) {

        if (sala.length() <= 15) {

            this.sala = sala;

        } else {

            return;
        }
    }

    public Float getValor() {
        return valor;
    }

    public void setValor(Float valor) {

        ValidationUtils validationUtils = new ValidationUtils();

        if (validationUtils.checkFloatLenght(valor, 6, 2)) {

            this.valor = valor;

        } else {

            return;
        }
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {

        if (tipo.length() <= 45) {

            this.tipo = tipo;

        } else {

            return;
        }
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {

        if (descricao.length() <= 65535) {

            this.descricao = descricao;

        } else {

            return;
        }
    }

    public List<Medico> getMedicos() {
        return medicos;
    }

    public void setMedicos(List<Medico> medicos) {
        this.medicos = medicos;
    }

    public List<Enfermeiro> getEnfermeiros() {
        return enfermeiros;
    }

    public void setEnfermeiros(List<Enfermeiro> enfermeiros) {
        this.enfermeiros = enfermeiros;
    }

    @Override
    public String toString() {
        return "Procedimento{" +
                "id=" + id +
                ", paciente=" + paciente +
                ", sala='" + sala + '\'' +
                ", valor=" + valor +
                ", tipo='" + tipo + '\'' +
                ", data=" + data +
                ", horario=" + horario +
                ", descricao='" + descricao + '\'' +
                ", medicos=" + medicos +
                ", enfermeiros=" + enfermeiros +
                '}';
    }
}
