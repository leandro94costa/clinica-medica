package br.com.clinica.service;

import br.com.clinica.dao.MedicoEspecialidadeDAO;
import br.com.clinica.entity.Especialidade;
import br.com.clinica.entity.Medico;
import br.com.clinica.entity.MedicoEspecialidade;

public class MedicoEspecialidadeService {

    public Integer add(Especialidade especialidade, Medico medico) {

        MedicoEspecialidadeDAO medicoEspecialidadeDAO = new MedicoEspecialidadeDAO();
        MedicoEspecialidade medicoEspecialidade = new MedicoEspecialidade();

        medicoEspecialidade.setEspecialidade(especialidade);
        medicoEspecialidade.setMedico(medico);

        medicoEspecialidadeDAO.insert(medicoEspecialidade);

        return 1;
    }
}
