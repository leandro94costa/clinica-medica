package br.com.clinica.cui;

import br.com.clinica.entity.Especialidade;
import br.com.clinica.entity.Usuario;
import br.com.clinica.service.EspecialidadeService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EspecialidadeCUI extends GenericCUI {

    public void menu(Usuario usuario) {

        Scanner scanner = new Scanner(System.in);
        Integer opcao = -1;

        System.out.println("--------------------------------------------------------------");
        System.out.println("** Especialidades **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        do {

            System.out.println(" 1 - Cadastrar");
            System.out.println();
            System.out.println(" 2 - Alterar");
            System.out.println();
            System.out.println(" 0 - Voltar");
            System.out.println();

            opcao = scanner.nextInt();

            switch (opcao) {

                case 1:
                    cadastrarOuAlterar(usuario, "cadastrar");
                    break;

                case 2:
                    cadastrarOuAlterar(usuario, "alterar");
                    break;

                case 0:
                    MenuCUI menuCUI = new MenuCUI();
                    menuCUI.menu(usuario);
                    break;

                default:
                    System.err.println("Opção inválida, tente novamente");
                    break;
            }

        } while (opcao < 0 && opcao > 2);
    }

    private void cadastrarOuAlterar(Usuario usuario, String metodo) {

        Scanner scanner = new Scanner(System.in);
        Especialidade especialidade = null;
        EspecialidadeService especialidadeService = new EspecialidadeService();
        Integer resultado;

        String titulo = metodo.substring(1);

        System.out.println("--------------------------------------------------------------");
        System.out.println("** A" + titulo + " Especialidade **");
        System.out.println("--------------------------------------------------------------");
        System.out.println();

        if (metodo.equals("alterar")) {

            especialidade = buscarEspecialidade();

            System.out.println("\n" + "Novas informações" + "\n");
        }

        do {

            System.out.println("Descrição: ");
            String nome = scanner.next();

            especialidade.setDescricao(nome);

            resultado = especialidadeService.save(especialidade);

            if (resultado > 0) {

                System.err.println("Erro ao " + metodo + " especialidade");
                System.out.println("Digite:" + "\n" + "0 - Tentar novamente"  + "\n" + "1 - Voltar");
                resultado = scanner.nextInt();

            } else {

                metodo = metodo.equals("cadastrar") ? "cadastrada" : "alterada";

                System.out.println();
                System.out.println("Funcionário " + metodo + " com sucesso");
                System.out.println();
            }

        } while (resultado == 0);

        menu(usuario);
    }

    public Especialidade buscarEspecialidade() {

        Scanner scanner = new Scanner(System.in);
        EspecialidadeService especialidadeService = new EspecialidadeService();
        Especialidade especialidade = null;
        Integer idEspecialidade = 0;

        do {

            System.out.println("Digite o nome da especialidade para buscar: ");
            String nomeEspecialidade = scanner.next();

            List<Especialidade> especialidades = especialidadeService.findByNome(nomeEspecialidade);

            if (especialidades.isEmpty()) {

                System.err.println("\n" + "Especialidade não encontrada" + "\n");

            } else {

                System.out.println();
                especialidades.forEach(System.out::println);
                System.out.println();

                System.out.println("Digite o ID da especialidade ou 0 para buscar novamente" + "\n" + "-1 - Sair");
                idEspecialidade = scanner.nextInt();
            }

        } while (idEspecialidade == 0);

        if (idEspecialidade != -1) {

            especialidade = especialidadeService.findById(idEspecialidade);
        }

        return especialidade;
    }

    public List<Especialidade> cadastrarEspecialidadesMedico(Integer id) {

        Scanner scanner = new Scanner(System.in);
        Boolean sair = false;
        List<Especialidade> especialidades = new ArrayList<>();
        EspecialidadeService especialidadeService = new EspecialidadeService();

        do {

            Especialidade especialidade = buscarEspecialidade();

            if (especialidade != null) {

                System.out.println("Especialidade: " + especialidade.getDescricao() + "\n" + "1 - Adicionar" + "\n" + "0 - Sair");
                Integer opcao = scanner.nextInt();

                if (opcao == 1) {

                    especialidades.add(especialidadeService.findById(especialidade.getId()));

                } else {

                    sair = true;
                }
            }

        } while (!sair);

        return especialidades;
    }
}
