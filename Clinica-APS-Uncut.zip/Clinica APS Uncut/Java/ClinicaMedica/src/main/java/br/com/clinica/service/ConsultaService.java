package br.com.clinica.service;

import br.com.clinica.dao.ConsultaDAO;
import br.com.clinica.entity.Consulta;
import br.com.clinica.entity.Medico;
import br.com.clinica.entity.Usuario;
import br.com.clinica.util.FormatterUtil;

import java.time.LocalDate;
import java.util.List;

public class ConsultaService {

    public Integer save(Consulta consulta) {

        ConsultaDAO consultaDAO = new ConsultaDAO();
        Integer resultado = 0;

        if (consulta.getId() == null) {

            if (consultaDAO.isAvailable(consulta)) {

                resultado = consultaDAO.insert(consulta);

            } else {

                resultado = -1;
            }

        } else {

            if (consultaDAO.isAvailable(consulta)) {

                consultaDAO.update(consulta);

                if (isChanged(consulta)) {

                    return 1;
                }

            } else {

                resultado = -1;
            }
        }

        return resultado;
    }

    private boolean isChanged(Consulta consulta) {

        ConsultaDAO consultaDAO = new ConsultaDAO();

        Consulta consultaPersisted = consultaDAO.find(consulta.getId());

        if (consultaPersisted.equals(consulta)) {

            return true;

        } else {

            return false;
        }
    }

    public List<Consulta> findByByNomeAndData(String nome, String data) {

        ConsultaDAO consultaDAO = new ConsultaDAO();
        FormatterUtil formatterUtil = new FormatterUtil();

        List<Consulta> consultas = consultaDAO.findConsultasByNomeAndData(nome, formatterUtil.formatDate(data));

        return consultas;
    }

    public String delete(Integer idConsulta) {

        ConsultaDAO consultaDAO = new ConsultaDAO();
        String resultado = "Ocorreu um problema ao desmarcar a consulta" + "\n" + "Tente novamente, por favor";

        consultaDAO.delete(idConsulta);

        try {

            Consulta consulta = consultaDAO.find(idConsulta);

            if (consulta == null) {

                resultado = "Consulta desmarcada com sucesso";
            }

        } catch (Exception e) {

            resultado = e.getMessage();
        }

        return resultado;
    }

    public List<Consulta> findConsultasHoje(Usuario usuario) {

        ConsultaDAO consultaDAO = new ConsultaDAO();
        MedicoService medicoService = new MedicoService();

        Medico medico = medicoService.findMedicoByUsuario(usuario);

        List<Consulta> consultas = consultaDAO.findConsultasByMedico(LocalDate.now(), medico.getId());

        return consultas;
    }

    public List<Consulta> findConsultasByPacienteAndMedico(Integer idPaciente, Usuario usuario) {

        MedicoService medicoService = new MedicoService();
        ConsultaDAO consultaDAO = new ConsultaDAO();

        Medico medico = medicoService.findMedicoByUsuario(usuario);

        List<Consulta> consultas = consultaDAO.findConsultasByPacienteAndMedico(idPaciente, medico.getId());

        return consultas;
    }

    public List<Consulta> findByPeriodoAndMedico(String dataInicial, String dataFinal, Usuario usuario) {

        MedicoService medicoService = new MedicoService();
        ConsultaDAO consultaDAO = new ConsultaDAO();
        FormatterUtil formatterUtil = new FormatterUtil();

        Medico medico = medicoService.findMedicoByUsuario(usuario);

        List<Consulta> consultas = consultaDAO.findConsultaByPeriodoAndMedico(formatterUtil.formatDate(dataInicial),
                formatterUtil.formatDate(dataFinal), medico.getId());

        return consultas;
    }

    public Consulta find(Integer idConsulta) {

        ConsultaDAO consultaDAO = new ConsultaDAO();

        Consulta consulta = consultaDAO.find(idConsulta);

        return consulta;
    }
}
